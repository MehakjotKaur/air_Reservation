<?php
require_once '../../controllers/admin/adminController.php';
require_once '../../controllers/admin/addflightController.php';
require_once 'addFlight.php';
?>