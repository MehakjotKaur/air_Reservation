<html>
  <body>
    <div class="split left">
      <div class="centered">
        <h4 style="color: beige;">Menu</h4>
        <ul class="fa-ul">
          <li>
            <a href="addadmin.php" style="color: #4caf50;"
              ><i class="fa fa-user-plus" style="font-size:30px;color:blue"></i> Add
              Admin</a
            >
          </li>
          <li>
            <a href="updateadmin.php" style="color: #4caf50;"
              ><i class="fa fa-refresh" style="font-size:30px;color:DarkCyan "></i> Update
              Admin</a
            >
          </li>
          <li>
            <a href="showadmin.php" style="color: #4caf50;"
              ><i class="fa fa-group" style="font-size:30px;color:DarkKhaki"></i> Show Admin</a
            >
          </li>
          <li>
            <a href="removeadmin.php" style="color: #4caf50;"
              ><i class="fa fa-close" style="font-size:30px;color:red"></i> Remove
              Admin</a
            >
          </li>
          <li>
          <a href="contactUs.php" style="color: #4caf50;"><i class="fa fa-commenting-o" style="font-size:30px;color:#E3CECA"></i>Contact </a>
          </li>
        </ul>
      </div>
    </div>
  </body>
</html>
