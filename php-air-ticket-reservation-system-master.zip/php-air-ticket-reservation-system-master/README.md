# Air-Ticket-Reservation-System
1. import database file from storage/databaseFile.
2. Set serverName, userName, password, dbName.
